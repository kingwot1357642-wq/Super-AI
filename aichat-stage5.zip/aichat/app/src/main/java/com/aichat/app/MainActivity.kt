package com.aichat.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import com.llamatik.library.platform.GenStream
import com.llamatik.library.platform.LlamaBridge
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

val Purple = Color(0xFF7B2FF7)
val Panel = Color(0xFF0D0D0D)

data class Msg(val fromUser: Boolean, val text: String)
data class Cfg(val url: String, val key: String, val model: String, val local: Boolean = false, val temp: Float = 0.4f, val analyze: Boolean = false)
data class Persona(val id: String, val name: String, val personality: String, val background: String, val avatar: String)
data class Target(val id: String, val name: String, val avatar: String, val prompt: String)
data class Mem(val text: String, val imp: Int, val t: Long)
data class PState(val rel: Int = 10, val emo: String = "calm", val mems: List<Mem> = emptyList())
data class Group(val id: String, val name: String, val desc: String, val avatar: String, val members: List<String>)
data class GMsg(val s: String, val t: String)

val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
lateinit var appCtx: Context
var appLocal = false

val EMO = mapOf(
    "calm" to "สงบ 😌", "happy" to "มีความสุข 😊", "excited" to "ตื่นเต้น 🤩", "sad" to "เศร้า 😢",
    "angry" to "โกรธ 😠", "anxious" to "กังวล 😟", "lonely" to "เหงา 🥺", "embarrassed" to "เขิน 😳", "tired" to "เหนื่อย 😴"
)
fun emoLabel(e: String) = EMO[e] ?: EMO["calm"]!!
fun relLabel(r: Int) = when {
    r < 0 -> "ไม่ถูกกัน"; r < 15 -> "คนรู้จัก"; r < 35 -> "คุ้นเคย"; r < 60 -> "เพื่อน"; r < 80 -> "เพื่อนสนิท"; else -> "สนิทมาก"
}

fun sim(a: String, b: String): Double {
    fun bg(x: String) = x.filter { !it.isWhitespace() }.windowed(2).toSet()
    val x = bg(a); val y = bg(b)
    if (x.isEmpty() || y.isEmpty()) return 0.0
    return 2.0 * x.intersect(y).size / (x.size + y.size)
}

fun overlap(mem: String, q: String): Double {
    fun bg(x: String) = x.filter { !it.isWhitespace() }.windowed(2).toSet()
    val a = bg(mem); val b = bg(q)
    if (a.isEmpty() || b.isEmpty()) return 0.0
    return a.intersect(b).size.toDouble() / a.size
}

fun stateContext(s: PState, query: String = "", max: Int = if (appLocal) 4 else 12): String {
    val ranked = if (query.isBlank()) s.mems.sortedWith(compareByDescending<Mem> { it.imp }.thenByDescending { it.t })
    else s.mems.sortedByDescending { it.imp * 0.1 + overlap(it.text, query) * 2 + (if (it.imp >= 5) 1.0 else 0.0) }
    val top = ranked.take(max)
    return "\nความสัมพันธ์กับผู้ใช้ตอนนี้: ${relLabel(s.rel)} (ปรับน้ำเสียงและความสนิทให้สอดคล้อง ห้ามพูดถึงคะแนน)" +
        "\nอารมณ์ตอนนี้: ${emoLabel(s.emo)} (แสดงออกอย่างเป็นธรรมชาติ)" +
        (if (top.isEmpty()) "" else "\nความทรงจำสำคัญ:\n" + top.joinToString("\n") { "- " + it.text })
}

const val ASSISTANT_PROMPT = "คุณคือ Assistant ผู้ช่วยประจำแอป พูดสุภาพ เป็นกันเอง ตอบเป็นภาษาเดียวกับผู้ใช้"

class Store(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
    fun cfg() = Cfg(
        p.getString("url", "") ?: "", p.getString("key", "") ?: "", p.getString("model", "") ?: "",
        p.getBoolean("local", false), p.getFloat("temp", 0.4f), p.getBoolean("analyze", false)
    )
    fun saveCfg(c: Cfg) {
        p.edit().putString("url", c.url).putString("key", c.key).putString("model", c.model)
            .putBoolean("local", c.local).putFloat("temp", c.temp).putBoolean("analyze", c.analyze).apply()
        appLocal = c.local
    }

    private fun key(id: String) = if (id == "assistant") "chat_assistant" else "chat_$id"
    fun loadChat(id: String): List<Msg> {
        val a = JSONArray(p.getString(key(id), "[]"))
        return List(a.length()) { val o = a.getJSONObject(it); Msg(o.getBoolean("u"), o.getString("t")) }
    }
    fun saveChat(id: String, m: List<Msg>) {
        val a = JSONArray()
        m.forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
        p.edit().putString(key(id), a.toString()).apply()
    }
    fun deleteChat(id: String) = p.edit().remove(key(id)).remove("state_$id").apply()

    fun state(id: String): PState {
        val s = p.getString("state_$id", null) ?: return PState()
        return try {
            val o = JSONObject(s)
            val a = o.getJSONArray("m")
            PState(o.getInt("r"), o.getString("e"), List(a.length()) {
                val m = a.getJSONObject(it); Mem(m.getString("t"), m.getInt("i"), m.getLong("c"))
            })
        } catch (e: Exception) { PState() }
    }
    fun saveState(id: String, s: PState) {
        val a = JSONArray()
        s.mems.forEach { a.put(JSONObject().put("t", it.text).put("i", it.imp).put("c", it.t)) }
        p.edit().putString("state_$id", JSONObject().put("r", s.rel).put("e", s.emo).put("m", a).toString()).apply()
    }

    fun personas(): List<Persona> {
        val a = JSONArray(p.getString("personas", "[]"))
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Persona(o.getString("id"), o.getString("name"), o.getString("p"), o.getString("b"), o.optString("a", ""))
        }
    }
    fun savePersonas(l: List<Persona>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("p", it.personality).put("b", it.background).put("a", it.avatar)) }
        p.edit().putString("personas", a.toString()).apply()
    }

    fun groups(): List<Group> {
        val a = JSONArray(p.getString("groups", "[]"))
        return List(a.length()) {
            val o = a.getJSONObject(it)
            val m = o.getJSONArray("m")
            Group(o.getString("id"), o.getString("n"), o.optString("d", ""), o.optString("a", ""), List(m.length()) { i -> m.getString(i) })
        }
    }
    fun saveGroups(l: List<Group>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("d", it.desc).put("a", it.avatar).put("m", JSONArray(it.members))) }
        p.edit().putString("groups", a.toString()).apply()
    }
    fun loadG(id: String): List<GMsg> {
        val a = JSONArray(p.getString("gchat_$id", "[]"))
        return List(a.length()) { val o = a.getJSONObject(it); GMsg(o.getString("s"), o.getString("t")) }
    }
    fun saveG(id: String, m: List<GMsg>) {
        val a = JSONArray()
        m.forEach { a.put(JSONObject().put("s", it.s).put("t", it.t)) }
        p.edit().putString("gchat_$id", a.toString()).apply()
    }
    fun deleteG(id: String) = p.edit().remove("gchat_$id").apply()
    fun removeMember(pid: String) = saveGroups(groups().map { it.copy(members = it.members - pid) })

    private fun dir() = File(ctx.filesDir, "gallery").apply { mkdirs() }
    fun file(name: String) = File(dir(), name)
    fun gallery(): List<String> = dir().listFiles()?.map { it.name }?.sortedDescending() ?: emptyList()
    fun deleteImage(name: String) { file(name).delete() }
    fun addImage(uri: Uri): Boolean {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 800) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)!!.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return false
            file("img_${System.currentTimeMillis()}.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return true
        } catch (e: Exception) {
            return false
        }
    }
}

fun targetOf(store: Store, id: String): Target {
    val ps = store.personas().find { it.id == id } ?: return Target("assistant", "Assistant", "", ASSISTANT_PROMPT)
    val prompt = "คุณคือ ${ps.name} ตัวละครในแอปแชต จงเล่นบทบาทนี้อย่างเป็นธรรมชาติ ห้ามหลุดบทบาท ตอบเป็นภาษาเดียวกับผู้ใช้\n" +
        "บุคลิก: ${ps.personality.take(400)}\nภูมิหลัง: ${ps.background.take(400)}\nคุยแบบเพื่อน ตอบสั้น ๆ 1-3 ประโยค ใช้ภาษาพูดเป็นธรรมชาติ ไม่ต้องอธิบายยาว"
    return Target(ps.id, ps.name, ps.avatar, prompt)
}

suspend fun callModel(cfg: Cfg, system: String, history: List<Msg>, remote: Boolean = false): String =
    if (cfg.local && !remote) Local.generate(cfg, system, history) else callRemote(cfg, system, history)

object Local {
    private val mutex = Mutex()
    private var loaded: String? = null
    fun file(ctx: Context) = File(File(ctx.filesDir, "models").apply { mkdirs() }, "model.gguf")
    fun reset() {
        loaded = null
        try { LlamaBridge.shutdown() } catch (e: Throwable) { }
    }

    suspend fun generate(cfg: Cfg, system: String, history: List<Msg>): String = mutex.withLock {
        withContext(Dispatchers.IO) {
            val f = file(appCtx)
            if (!f.exists()) error("ยังไม่ได้ติดตั้งโมเดลในเครื่อง (เพิ่มเติม > Model Connection)")
            LlamaBridge.updateGenerateParams(
                temperature = cfg.temp, maxTokens = 200, topP = 0.9f, topK = 40, repeatPenalty = 1.1f,
                contextLength = 2048, numThreads = 4, useMmap = true, flashAttention = false, batchSize = 256, gpuLayers = 0
            )
            if (loaded != f.path) {
                if (!LlamaBridge.initGenerateModel(f.path)) error("โหลดโมเดลไม่สำเร็จ ไฟล์อาจเสียหรือไม่ใช่ GGUF")
                loaded = f.path
            }
            val h = history.takeLast(10)
            val turns = ArrayList<Pair<String, String>>()
            turns.add("system" to system)
            h.forEach { turns.add((if (it.fromUser) "user" else "assistant") to it.text) }
            val prompt = LlamaBridge.applyChatTemplate(turns, true)
            val done = CompletableDeferred<String>()
            val sb = StringBuilder()
            val cb = object : GenStream {
                override fun onDelta(text: String) { sb.append(text) }
                override fun onComplete() { done.complete(sb.toString()) }
                override fun onError(message: String) { done.completeExceptionally(RuntimeException(message)) }
            }
            if (prompt != null) LlamaBridge.generateStream(prompt, cb)
            else {
                val ctxText = h.dropLast(1).joinToString("\n") { (if (it.fromUser) "ผู้ใช้: " else "ตัวละคร: ") + it.text }
                LlamaBridge.generateStreamWithContext(system, ctxText, h.lastOrNull()?.text ?: "", cb)
            }
            done.await().replace(Regex("<\\|[^|]*\\|>"), "").trim()
        }
    }
}

val SAD = listOf("เศร้า", "เสียใจ", "ร้องไห้", "เหงา", "ท้อ", "เครียด", "ผิดหวัง")
val TIRED = listOf("ง่วง", "เพลีย", "เหนื่อย")
val WORRY = listOf("กังวล", "กลัว", "เป็นห่วง", "ไม่สบาย")
val JOY = listOf("ดีใจ", "สนุก", "555", "ฮ่าๆ", "มีความสุข", "เย้")
val EXCITE = listOf("ตื่นเต้น", "สุดยอด", "ได้แล้ว", "ชนะ", "สอบผ่าน", "ได้งาน", "เลื่อนตำแหน่ง", "ได้รางวัล")
val LOVE = listOf("รักนะ", "คิดถึง", "น่ารัก", "ชอบเธอ", "ชอบเรา", "รักเธอ", "ชอบคุณ", "รักคุณ")
val THANKS = listOf("ขอบคุณ", "ขอบใจ")
val ANGRY = listOf("เกลียด", "โง่", "น่ารำคาญ", "หุบปาก", "ไปไกล", "ไม่คุยแล้ว", "โกรธ", "ไร้ประโยชน์", "ห่วย")
val SORRY = listOf("ขอโทษ", "โทษที")
val NAME_RE = Regex("(?:เรียกฉันว่า|เรียกเราว่า|เรียกผมว่า|เรียกหนูว่า|ฉันชื่อ|เราชื่อ|ผมชื่อ|หนูชื่อ|ชื่อเล่น(?:ของ(?:ฉัน|เรา|ผม|หนู))?(?:คือ)?)\\s*([^\\s,.!?]{1,20})")
val LIKE_RE = Regex("(?<!ไม่)ชอบ\\s*([^\\s,.!?]{2,25})")
val DISLIKE_RE = Regex("ไม่ชอบ\\s*([^\\s,.!?]{2,25})")
val FACT_RE = Regex("(?:ฉัน|เรา|ผม|หนู)(?:ทำงาน|เรียน|อยู่ที่|อาศัยอยู่|มีแมว|มีหมา|มีน้อง|มีพี่)[^\\n.!?]{0,40}")

fun hit(t: String, l: List<String>) = l.any { t.contains(it) }

// ระบบจำ/อารมณ์/ความสัมพันธ์แบบกฎ ทำงานในแอปเอง ไม่ใช้โมเดล
fun brain(store: Store, id: String, text: String, first: Boolean) {
    val cur = store.state(id)
    var emo = cur.emo
    var d = 0
    val mems = cur.mems.toMutableList()
    val t = text.trim()
    val sentences = t.split(Regex("[\\n.!?。]+")).map { it.trim() }.filter { it.isNotEmpty() }
    fun sent(w: String) = (sentences.firstOrNull { it.contains(w) } ?: t).take(80)
    fun add(m: String, imp: Int) {
        if (mems.none { sim(it.text, m) > 0.55 }) mems.add(Mem(m, imp, System.currentTimeMillis()))
    }
    val angry = hit(t, ANGRY)
    when {
        angry -> { emo = "angry"; d -= 5; add("ผู้ใช้พูดไม่ดีใส่เรา/ทะเลาะกัน: " + sent(ANGRY.first { t.contains(it) }), 4) }
        hit(t, SORRY) -> {
            if (cur.emo == "angry") { d += 3; emo = "calm"; add("ผู้ใช้ขอโทษและเราคืนดีกัน", 4) } else d += 1
        }
        hit(t, SAD) -> emo = "sad"
        hit(t, WORRY) -> emo = "anxious"
        hit(t, EXCITE) -> { emo = "excited"; d += 1 }
        hit(t, LOVE) -> { emo = "embarrassed"; d += 2 }
        hit(t, THANKS) -> { emo = "happy"; d += 2 }
        hit(t, JOY) -> { emo = "happy"; d += 1 }
        hit(t, TIRED) -> emo = "tired"
        else -> if (cur.emo != "calm" && Random.nextInt(100) < 40) emo = "calm"
    }
    if (!angry && d == 0 && t.length > 8 && Random.nextInt(100) < 50) d += 1

    if (first) add("เริ่มคุยกับผู้ใช้เป็นครั้งแรกเมื่อ " + SimpleDateFormat("d/M/yyyy", Locale.US).format(Date()), 4)
    if (t.contains("วันเกิด")) add("ผู้ใช้เล่าเรื่องวันเกิด: " + sent("วันเกิด"), 4)
    NAME_RE.find(t)?.let { add("ผู้ใช้ชื่อหรืออยากให้เรียกว่า " + it.groupValues[1], 5) }
    LIKE_RE.find(t)?.groupValues?.get(1)
        ?.takeIf { !it.startsWith("เธอ") && !it.startsWith("คุณ") && !it.startsWith("เรา") }
        ?.let { add("ผู้ใช้ชอบ $it", 3) }
    DISLIKE_RE.find(t)?.let { add("ผู้ใช้ไม่ชอบ " + it.groupValues[1], 3) }
    for (w in listOf("สอบผ่าน", "ได้งาน", "เลื่อนตำแหน่ง", "ได้รางวัล", "สำเร็จ", "จบแล้ว")) {
        if (t.contains(w)) { add("ผู้ใช้ประสบความสำเร็จ: " + sent(w), 4); break }
    }
    if (t.contains("ขอบคุณที่ช่วย")) add("ผู้ใช้ขอบคุณที่เราช่วย: " + sent("ขอบคุณที่ช่วย"), 3)
    FACT_RE.find(t)?.let { add("ผู้ใช้เล่าว่า: " + it.value.trim(), 3) }

    val kept = if (mems.size > 60) mems.sortedWith(compareByDescending<Mem> { it.imp }.thenByDescending { it.t }).take(60) else mems
    store.saveState(id, PState((cur.rel + d).coerceIn(-50, 100), emo, kept))
}

suspend fun callRemote(cfg: Cfg, system: String, history: List<Msg>): String = withContext(Dispatchers.IO) {
    if (cfg.url.isBlank() || cfg.model.isBlank()) error("ยังไม่ได้ตั้งค่า More > Model Connection")
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
    history.takeLast(20).forEach {
        msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
    }
    val body = JSONObject().put("model", cfg.model).put("messages", msgs)
    val conn = (URL(cfg.url.trim().trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        setRequestProperty("Content-Type", "application/json")
        if (cfg.key.isNotBlank()) setRequestProperty("Authorization", "Bearer " + cfg.key.trim())
        doOutput = true
        connectTimeout = 20000
        readTimeout = 120000
    }
    conn.outputStream.use { it.write(body.toString().toByteArray()) }
    val code = conn.responseCode
    val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
    if (code !in 200..299) error("HTTP $code ${text.take(200)}")
    JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
}

suspend fun analyze(store: Store, id: String, window: List<Msg>, convoText: String? = null, ctx: String = "") {
    val ps = store.personas().find { it.id == id } ?: return
    if (window.isEmpty()) return
    val cur = store.state(id)
    val convo = convoText ?: window.joinToString("\n") { (if (it.fromUser) "ผู้ใช้" else ps.name) + ": " + it.text }
    val known = if (cur.mems.isEmpty()) "(ยังไม่มี)" else cur.mems.joinToString("\n") { "- " + it.text }
    val sys = "คุณคือระบบวิเคราะห์ของแอปแชตตัวละคร AI วิเคราะห์บทสนทนาระหว่างผู้ใช้กับตัวละคร ${ps.name}\n" +
        "บุคลิก: ${ps.personality}\nภูมิหลัง: ${ps.background}\n" +
        ctx + "ความสัมพันธ์ที่ตัวละครมีต่อผู้ใช้ตอนนี้: ${relLabel(cur.rel)}\nอารมณ์ตอนนี้: ${cur.emo}\n" +
        "ความทรงจำที่มีอยู่แล้ว:\n$known\n\nบทสนทนา:\n$convo\n\n" +
        "ตอบเป็น JSON เท่านั้น ไม่มีข้อความอื่น รูปแบบ:\n" +
        "{\"relationship_delta\": จำนวนเต็ม -10 ถึง 10, \"emotion\": ค่าใดค่าหนึ่งจาก [calm,happy,excited,sad,angry,anxious,lonely,embarrassed,tired], " +
        "\"memories\": [{\"text\": \"ประโยคสั้น ๆ จากมุมมองตัวละคร\", \"importance\": 1-5}]}\n" +
        "กติกา: ความสัมพันธ์ค่อย ๆ เปลี่ยน คุยทั่วไป 0 ถึง +2 เหตุการณ์สำคัญหรือการทะเลาะเปลี่ยนมากขึ้น; " +
        "emotion คืออารมณ์ของตัวละครหลังบทสนทนานี้; memories ใส่เฉพาะเรื่องสำคัญที่คนทั่วไปมักจำได้ " +
        "(วันเกิด การพบกันครั้งแรก ทะเลาะ คืนดี การช่วยเหลือ ความสำเร็จ ข้อมูลส่วนตัวสำคัญ) ห้ามใส่เรื่องเล็กน้อยหรือซ้ำกับที่มีอยู่แล้ว ถ้าไม่มีให้เป็น []"
    val raw = callModel(store.cfg(), sys, listOf(Msg(true, "วิเคราะห์แล้วตอบเป็น JSON")), remote = true)
    val a = raw.indexOf('{')
    val b = raw.lastIndexOf('}')
    if (a < 0 || b <= a) return
    val j = JSONObject(raw.substring(a, b + 1))
    val d = j.optInt("relationship_delta", 0).coerceIn(-10, 10)
    val emo = j.optString("emotion", cur.emo).trim().lowercase().let { if (EMO.containsKey(it)) it else cur.emo }
    val mems = cur.mems.toMutableList()
    val arr = j.optJSONArray("memories")
    if (arr != null) for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val text = o.optString("text").trim()
        val imp = o.optInt("importance", 3)
        if (text.isEmpty() || imp < 3) continue
        if (mems.any { sim(it.text, text) > 0.55 }) continue
        mems.add(Mem(text, imp.coerceIn(1, 5), System.currentTimeMillis()))
    }
    val kept = if (mems.size > 60) mems.sortedWith(compareByDescending<Mem> { it.imp }.thenByDescending { it.t }).take(60) else mems
    val latest = store.state(id)
    store.saveState(id, PState((latest.rel + d).coerceIn(-50, 100), emo, kept))
}

fun groupPrompt(ps: Persona, st: PState, g: Group, names: List<String>, q: String = ""): String =
    "คุณคือ ${ps.name} ตัวละครในแอปแชต จงเล่นบทบาทนี้อย่างเป็นธรรมชาติ ห้ามหลุดบทบาท ตอบเป็นภาษาเดียวกับผู้ใช้\n" +
        "บุคลิก: ${ps.personality}\nภูมิหลัง: ${ps.background}\n" +
        "ตอนนี้คุณอยู่ในกลุ่มแชต \"${g.name}\"" + (if (g.desc.isBlank()) "" else " (${g.desc})") +
        " สมาชิก: ผู้ใช้ (ชื่อ \"คุณ\"), ${names.joinToString(", ")} ทุกคนมีสถานะเท่าเทียมกัน\n" +
        "ข้อความของคนอื่นจะขึ้นต้นด้วยชื่อผู้พูด ให้ตอบเป็นข้อความแชตสั้น ๆ 1-2 ประโยค ไม่ต้องใส่ชื่อนำหน้า ไม่พูดแทนคนอื่น " +
        "ถ้าตอนนี้ไม่มีอะไรจะพูดให้ตอบว่า [pass] ทุกคนไม่ต้องพูดทุกครั้ง" + stateContext(st, q)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appCtx = applicationContext
        appLocal = Store(appCtx).cfg().local
        setContent { App(applicationContext) }
    }
}

@Composable
fun fc() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Purple.copy(alpha = 0.5f))

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var chatId by remember { mutableStateOf<String?>(null) }
    var gid by remember { mutableStateOf<String?>(null) }
    var sub by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = chatId != null || sub != null || gid != null) {
        val s0 = sub
        if (s0 != null) sub = if (s0.startsWith("edit:")) "manage" else null
        else if (gid != null) gid = null
        else chatId = null
    }
    val cid = chatId
    val gd = gid
    val sb = sub
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color.Black, surface = Color.Black)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            when {
                sb == "gnew" -> GroupCreateScreen(store) { sub = null }
                sb != null && sb.startsWith("ginfo:") -> GroupInfoScreen(store, sb.removePrefix("ginfo:"), { sub = null }) { sub = null; gid = null }
                gd != null -> GroupChatScreen(store, gd, { sub = "ginfo:$gd" }) { gid = null }
                cid != null -> ChatScreen(store, targetOf(store, cid)) { chatId = null }
                sb == "model" -> ModelScreen(store) { sub = null }
                sb == "char" -> CreateScreen(store) { sub = null }
                sb == "gallery" -> GalleryScreen(store) { sub = null }
                sb == "manage" -> ManageScreen(store, { sub = null }) { sub = "edit:$it" }
                sb != null && sb.startsWith("edit:") -> EditScreen(store, sb.removePrefix("edit:")) { sub = "manage" }
                else -> Scaffold(
                    containerColor = Color.Black,
                    bottomBar = {
                        NavigationBar(containerColor = Panel) {
                            listOf("💬" to "แชต", "👥" to "กลุ่ม", "☰" to "เพิ่มเติม").forEachIndexed { i, (ic, t) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(ic, fontSize = 20.sp) }, label = { Text(t) },
                                    colors = NavigationBarItemDefaults.colors(indicatorColor = Purple.copy(alpha = 0.35f))
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            0 -> ChatList(store) { chatId = it }
                            1 -> GroupList(store, { gid = it }) { sub = "gnew" }
                            else -> MoreScreen { sub = it }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Center(t: String) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t, color = Color.Gray) }

@Composable
fun Avatar(store: Store, name: String, file: String, size: Int = 44) {
    val bmp = remember(file) { if (file.isBlank()) null else BitmapFactory.decodeFile(store.file(file).path)?.asImageBitmap() }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size.dp).clip(CircleShape), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), color = Color.White, fontSize = (size / 2).sp)
        }
    }
}

@Composable
fun AvatarPicker(store: Store, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val g = remember { store.gallery() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("เลือกรูปโปรไฟล์") },
        text = {
            if (g.isEmpty()) Text("ยังไม่มีรูป ไปเพิ่มที่ เพิ่มเติม > Image Gallery ก่อน")
            else LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 300.dp)) {
                items(g) { n -> Box(Modifier.padding(4.dp).clickable { onPick(n) }) { Avatar(store, "", n, 76) } }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ปิด") } },
        dismissButton = { TextButton(onClick = { onPick("") }) { Text("ไม่ใช้รูป") } }
    )
}

@Composable
fun ChatList(store: Store, open: (String) -> Unit) {
    val items = listOf(Target("assistant", "Assistant", "", "")) + store.personas().map { Target(it.id, it.name, it.avatar, "") }
    Column(Modifier.fillMaxSize()) {
        Text("แชต", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        LazyColumn {
            items(items) { t ->
                val last = store.loadChat(t.id).lastOrNull()?.text ?: "แตะเพื่อเริ่มคุย"
                Row(Modifier.fillMaxWidth().clickable { open(t.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(store, t.name, t.avatar)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(t.name, color = Color.White, fontSize = 16.sp)
                        Text(last.take(50), color = Color.Gray, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(store: Store, target: Target, onBack: () -> Unit) {
    val msgs = remember { mutableStateListOf<Msg>().apply { addAll(store.loadChat(target.id)) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var st by remember { mutableStateOf(store.state(target.id)) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""; err = null
        msgs.add(Msg(true, t)); store.saveChat(target.id, msgs); busy = true
        if (target.id != "assistant") { brain(store, target.id, t, msgs.size <= 1); st = store.state(target.id) }
        scope.launch {
            try {
                val sys = if (target.id == "assistant") target.prompt else target.prompt + stateContext(store.state(target.id), t)
                val r = callModel(store.cfg(), sys, msgs.toList())
                msgs.add(Msg(false, r)); store.saveChat(target.id, msgs)
                if (target.id != "assistant" && store.cfg().analyze) {
                    val w = msgs.toList().takeLast(6)
                    appScope.launch {
                        try { analyze(store, target.id, w); st = store.state(target.id) } catch (e: Exception) { }
                    }
                }
            } catch (e: Exception) {
                err = "⚠️ " + (e.message ?: "เชื่อมต่อโมเดลไม่ได้")
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp, color = Color.White) }
            Avatar(store, target.name, target.avatar, 38)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(target.name, color = Color.White, fontSize = 16.sp)
                Text(if (busy) "กำลังพิมพ์..." else if (target.id == "assistant") "ออนไลน์" else emoLabel(st.emo) + " · " + relLabel(st.rel), color = Color.Gray, fontSize = 12.sp)
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.toList()) { Bubble(it) }
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("พิมพ์ข้อความ...") }, maxLines = 4, colors = fc()
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ส่ง") }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        val mod = if (m.fromUser) Modifier.background(Purple, shape)
        else Modifier.background(Color.Black, shape).border(1.dp, Purple, shape)
        Box(Modifier.widthIn(max = 280.dp).then(mod).padding(12.dp)) { Text(m.text, color = Color.White) }
    }
}

@Composable
fun MoreScreen(open: (String) -> Unit) {
    val items = listOf(
        "model" to "Model Connection — เชื่อมต่อโมเดล",
        "char" to "Create Character — สร้างตัวละคร",
        "gallery" to "Image Gallery — จัดการรูปโปรไฟล์",
        "manage" to "AI Management — จัดการ AI"
    )
    Column(Modifier.fillMaxSize()) {
        Text("เพิ่มเติม", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        items.forEach { (id, label) ->
            Text(label, color = Color.White, modifier = Modifier.fillMaxWidth().clickable { open(id) }.padding(16.dp))
            HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        }
    }
}

@Composable
fun BackRow(back: () -> Unit, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = back) { Text("←", fontSize = 22.sp, color = Color.White) }
        Text(title, fontSize = 20.sp, color = Color.White)
    }
}

@Composable
fun ModelScreen(store: Store, back: () -> Unit) {
    val c = remember { store.cfg() }
    var local by remember { mutableStateOf(c.local) }
    var temp by remember { mutableFloatStateOf(c.temp) }
    var analyze by remember { mutableStateOf(c.analyze) }
    var url by remember { mutableStateOf(c.url) }
    var key by remember { mutableStateOf(c.key) }
    var model by remember { mutableStateOf(c.model) }
    var dlUrl by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var hasModel by remember { mutableStateOf(Local.file(appCtx).exists()) }
    val scope = rememberCoroutineScope()

    fun finish(msg: String) { status = msg; hasModel = Local.file(appCtx).exists(); busy = false }
    fun checkGguf(f: File) {
        val h = ByteArray(4)
        f.inputStream().use { it.read(h) }
        if (String(h) != "GGUF") { f.delete(); error("ไฟล์นี้ไม่ใช่ GGUF") }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true; status = "กำลังคัดลอกไฟล์..."
            scope.launch {
                val r = try {
                    withContext(Dispatchers.IO) {
                        Local.reset()
                        val f = Local.file(appCtx)
                        appCtx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                        checkGguf(f)
                    }
                    "ติดตั้งโมเดลแล้ว ✓"
                } catch (e: Exception) { "⚠️ " + (e.message ?: "คัดลอกไม่สำเร็จ") }
                finish(r)
            }
        }
    }
    fun download() {
        val u = dlUrl.trim()
        if (!u.startsWith("http")) { status = "ลิงก์ไม่ถูกต้อง"; return }
        busy = true; status = "กำลังดาวน์โหลด 0%"
        scope.launch {
            val r = try {
                withContext(Dispatchers.IO) {
                    Local.reset()
                    val conn = URL(u).openConnection() as HttpURLConnection
                    conn.instanceFollowRedirects = true
                    conn.connectTimeout = 20000
                    conn.readTimeout = 60000
                    if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                    val total = conn.contentLengthLong
                    val tmp = File(Local.file(appCtx).path + ".part")
                    conn.inputStream.use { i ->
                        tmp.outputStream().use { o ->
                            val buf = ByteArray(1 shl 16)
                            var n: Int
                            var sum = 0L
                            var last = -1
                            while (i.read(buf).also { n = it } >= 0) {
                                o.write(buf, 0, n); sum += n
                                if (total > 0) {
                                    val p = (sum * 100 / total).toInt()
                                    if (p != last) { last = p; status = "กำลังดาวน์โหลด $p%" }
                                }
                            }
                        }
                    }
                    checkGguf(tmp)
                    Local.file(appCtx).delete()
                    tmp.renameTo(Local.file(appCtx))
                }
                "ติดตั้งโมเดลแล้ว ✓"
            } catch (e: Exception) { "⚠️ " + (e.message ?: "ดาวน์โหลดไม่สำเร็จ") }
            finish(r)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "Model Connection")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = local, onCheckedChange = { local = it; saved = false })
            Spacer(Modifier.width(10.dp))
            Text("ใช้โมเดลในเครื่องสำหรับแชต", color = Color.White)
        }
        if (local) {
            Text(
                if (hasModel) "โมเดลในเครื่อง: ติดตั้งแล้ว ✓" else "โมเดลในเครื่อง: ยังไม่ได้ติดตั้ง",
                color = if (hasModel) Color(0xFF9CFF9C) else Color(0xFFFFC857)
            )
            Text("แนะนำ: Typhoon2 1B Instruct ไฟล์ GGUF แบบ Q4_K_M (ค้นบน Hugging Face ว่า llama3.2-typhoon2-1b-instruct-gguf)", color = Color.Gray, fontSize = 12.sp)
            Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("เลือกไฟล์ GGUF จากเครื่อง") }
            OutlinedTextField(dlUrl, { dlUrl = it }, label = { Text("หรือวางลิงก์ดาวน์โหลดไฟล์ .gguf") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
            OutlinedButton(onClick = { download() }, enabled = !busy && dlUrl.isNotBlank()) { Text("ดาวน์โหลด") }
            status?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
            Text("ความสุ่มของคำตอบ (temperature): " + "%.1f".format(temp), color = Color.White, fontSize = 14.sp)
            Slider(value = temp, onValueChange = { temp = it; saved = false }, valueRange = 0.1f..1.2f)
            Text("โมเดลเล็กควรใช้ค่าต่ำ ประมาณ 0.3–0.5", color = Color.Gray, fontSize = 12.sp)
        }
        HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        Text("โมเดลออนไลน์ (ใช้แชตเมื่อปิดโหมดในเครื่อง และใช้วิเคราะห์)", color = Color.White)
        Text("ใช้ได้กับ API แบบ OpenAI เช่น https://api.openai.com/v1, OpenRouter, Ollama (http://IP:11434/v1)", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(url, { url = it; saved = false }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(key, { key = it; saved = false }, label = { Text("API Key (เว้นว่างได้)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(model, { model = it; saved = false }, label = { Text("ชื่อโมเดล") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = analyze, onCheckedChange = { analyze = it; saved = false })
            Spacer(Modifier.width(10.dp))
            Text("วิเคราะห์ความทรงจำเพิ่มด้วยโมเดลออนไลน์ (ไม่บังคับ)", color = Color.White, fontSize = 14.sp)
        }
        Button(onClick = { store.saveCfg(Cfg(url, key, model, local, temp, analyze)); saved = true }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("บันทึก") }
        if (saved) Text("บันทึกแล้ว ✓", color = Color(0xFF9CFF9C))
    }
}

@Composable
fun GalleryScreen(store: Store, back: () -> Unit) {
    var imgs by remember { mutableStateOf(store.gallery()) }
    var del by remember { mutableStateOf<String?>(null) }
    var failed by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { failed = !store.addImage(uri); imgs = store.gallery() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        BackRow(back, "Image Gallery")
        Button(onClick = { launcher.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("+ เพิ่มรูป") }
        if (failed) Text("เพิ่มรูปไม่สำเร็จ", color = Color(0xFFFF6B6B))
        Text("แตะรูปเพื่อลบ", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyVerticalGrid(GridCells.Fixed(3)) {
            items(imgs) { n -> Box(Modifier.padding(4.dp).clickable { del = n }) { Avatar(store, "", n, 100) } }
        }
    }
    del?.let { n ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("ลบรูปนี้?") },
            confirmButton = { TextButton(onClick = { store.deleteImage(n); imgs = store.gallery(); del = null }) { Text("ลบ") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("ยกเลิก") } }
        )
    }
}

@Composable
fun CreateScreen(store: Store, back: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var pers by remember { mutableStateOf("") }
    var bg by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "Create Character")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name.ifBlank { "?" }, avatar, 64)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เลือกรูปโปรไฟล์") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อ") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(pers, { pers = it }, label = { Text("บุคลิก") }, minLines = 3, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(bg, { bg = it }, label = { Text("ภูมิหลัง") }, minLines = 3, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("⚠️ บุคลิกและภูมิหลังแก้ไขไม่ได้หลังสร้าง หากต้องการเปลี่ยนต้องสร้างตัวละครใหม่", color = Color(0xFFFFC857), fontSize = 12.sp)
        Button(
            onClick = {
                val ps = Persona(UUID.randomUUID().toString().take(8), name.trim(), pers.trim(), bg.trim(), avatar)
                store.savePersonas(store.personas() + ps); back()
            },
            enabled = name.isNotBlank() && pers.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("สร้างตัวละคร") }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
}

@Composable
fun ManageScreen(store: Store, back: () -> Unit, edit: (String) -> Unit) {
    val l = remember { store.personas() }
    Column(Modifier.fillMaxSize()) {
        BackRow(back, "AI Management")
        if (l.isEmpty()) Center("ยังไม่มีตัวละคร สร้างได้ที่ Create Character")
        LazyColumn {
            items(l) { ps ->
                Row(Modifier.fillMaxWidth().clickable { edit(ps.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(store, ps.name, ps.avatar)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(ps.name, color = Color.White, fontSize = 16.sp)
                        Text("แตะเพื่อจัดการ", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun EditScreen(store: Store, id: String, back: () -> Unit) {
    val orig = remember { store.personas().find { it.id == id } }
    if (orig == null) { Center("ไม่พบตัวละคร"); return }
    var name by remember { mutableStateOf(orig.name) }
    var avatar by remember { mutableStateOf(orig.avatar) }
    var pick by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var st by remember { mutableStateOf(store.state(id)) }
    var analyzing by remember { mutableStateOf(false) }
    var amsg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "จัดการ ${orig.name}")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name, avatar, 64)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เปลี่ยนรูปโปรไฟล์") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อ") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("🔒 บุคลิก (แก้ไขไม่ได้)", color = Color.Gray, fontSize = 12.sp)
        Text(orig.personality, color = Color.White)
        Text("🔒 ภูมิหลัง (แก้ไขไม่ได้)", color = Color.Gray, fontSize = 12.sp)
        Text(orig.background.ifBlank { "-" }, color = Color.White)
        HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        Text("ความสัมพันธ์กับคุณ: ${relLabel(st.rel)} (${st.rel})", color = Color.White)
        Text("อารมณ์ตอนนี้: ${emoLabel(st.emo)}", color = Color.White)
        Text("ความทรงจำ (${st.mems.size})", color = Color.Gray, fontSize = 12.sp)
        if (st.mems.isEmpty()) Text("ยังไม่มี", color = Color.Gray, fontSize = 14.sp)
        st.mems.sortedByDescending { it.t }.forEach { Text("• " + it.text, color = Color.White, fontSize = 14.sp) }
        OutlinedButton(
            enabled = !analyzing,
            onClick = {
                analyzing = true; amsg = null
                scope.launch {
                    try {
                        val chunks = store.loadChat(id).takeLast(60).chunked(20)
                        if (chunks.isEmpty()) amsg = "ยังไม่มีประวัติแชต"
                        else { chunks.forEach { analyze(store, id, it) }; amsg = "วิเคราะห์เสร็จแล้ว" }
                    } catch (e: Exception) { amsg = "⚠️ " + (e.message ?: "ผิดพลาด") }
                    st = store.state(id); analyzing = false
                }
            }
        ) { Text(if (analyzing) "กำลังวิเคราะห์..." else "วิเคราะห์ประวัติแชตย้อนหลัง") }
        amsg?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
        HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        Button(
            onClick = {
                store.savePersonas(store.personas().map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }, avatar = avatar) else it })
                back()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("บันทึก") }
        OutlinedButton(onClick = { confirm = true }) { Text("ลบตัวละคร", color = Color(0xFFFF6B6B)) }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("ลบ ${orig.name} และประวัติแชตทั้งหมด?") },
        confirmButton = {
            TextButton(onClick = { store.savePersonas(store.personas().filter { it.id != id }); store.deleteChat(id); store.removeMember(id); back() }) { Text("ลบ") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("ยกเลิก") } }
    )
}


@Composable
fun GroupList(store: Store, open: (String) -> Unit, onNew: () -> Unit) {
    val gs = remember { store.groups() }
    val ps = remember { store.personas() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("กลุ่ม", fontSize = 24.sp, color = Color.White, modifier = Modifier.weight(1f))
            Button(onClick = onNew, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("+ สร้างกลุ่ม") }
        }
        if (gs.isEmpty()) Center("ยังไม่มีกลุ่ม")
        LazyColumn {
            items(gs) { g ->
                val last = store.loadG(g.id).lastOrNull()
                val prev = if (last == null) "แตะเพื่อเริ่มคุย"
                else (if (last.s == "user") "คุณ" else ps.find { it.id == last.s }?.name ?: "?") + ": " + last.t
                Row(Modifier.fillMaxWidth().clickable { open(g.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(store, g.name, g.avatar)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(g.name, color = Color.White, fontSize = 16.sp)
                        Text(prev.take(50), color = Color.Gray, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun GBubble(store: Store, name: String, avatar: String, m: GMsg) {
    if (m.s == "user") Bubble(Msg(true, m.t))
    else Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Avatar(store, name, avatar, 32)
        Spacer(Modifier.width(8.dp))
        Column {
            Text(name, color = Color.Gray, fontSize = 12.sp)
            Bubble(Msg(false, m.t))
        }
    }
}

@Composable
fun GroupChatScreen(store: Store, gid: String, info: () -> Unit, onBack: () -> Unit) {
    val group = remember { store.groups().find { it.id == gid } }
    if (group == null) { Center("ไม่พบกลุ่ม"); return }
    val personas = remember { store.personas() }
    val members = remember { group.members.mapNotNull { m -> personas.find { it.id == m } } }
    val msgs = remember { mutableStateListOf<GMsg>().apply { addAll(store.loadG(gid)) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }
    fun nameOf(s: String) = if (s == "user") "คุณ" else personas.find { it.id == s }?.name ?: "?"

    fun round() {
        busy = true; err = null
        appScope.launch {
            val spoke = mutableListOf<Persona>()
            try {
                for (m in members.shuffled().take(4)) {
                    if (msgs.lastOrNull()?.s == m.id) continue
                    val hist = msgs.toList().takeLast(20).map { g ->
                        if (g.s == m.id) Msg(false, g.t) else Msg(true, nameOf(g.s) + ": " + g.t)
                    }
                    val h2 = if (hist.isEmpty()) listOf(Msg(true, "(ยังไม่มีใครพูด เริ่มชวนคุยในกลุ่มได้เลย)")) else hist
                    val sys = groupPrompt(m, store.state(m.id), group, members.filter { it.id != m.id }.map { it.name }, msgs.lastOrNull()?.t ?: "")
                    var r = callModel(store.cfg(), sys, h2).trim()
                    if (r.isEmpty() || r.contains("[pass]", ignoreCase = true)) continue
                    r = r.removePrefix(m.name + ":").trim()
                    msgs.add(GMsg(m.id, r)); store.saveG(gid, msgs); spoke.add(m)
                }
            } catch (e: Exception) {
                err = "⚠️ " + (e.message ?: "เชื่อมต่อโมเดลไม่ได้")
            }
            busy = false
            if (spoke.isNotEmpty() && store.cfg().analyze) {
                val convo = msgs.toList().takeLast(10).joinToString("\n") { nameOf(it.s) + ": " + it.t }
                val c = "บทสนทนานี้เกิดในกลุ่มแชต \"${group.name}\" ที่มีผู้ใช้และสมาชิก AI หลายคน ถ้าผู้ใช้ไม่ได้พูดในบทสนทนานี้ relationship_delta ให้เป็น 0 " +
                    "อารมณ์ได้รับผลจากเหตุการณ์ในกลุ่มด้วย\n"
                for (m in spoke) {
                    try { analyze(store, m.id, listOf(Msg(true, "x")), convo, c) } catch (e: Exception) { }
                }
            }
        }
    }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""
        msgs.add(GMsg("user", t)); store.saveG(gid, msgs)
        members.forEach { brain(store, it.id, t, false) }
        round()
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp, color = Color.White) }
            Avatar(store, group.name, group.avatar, 38)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(group.name, color = Color.White, fontSize = 16.sp)
                Text(if (busy) "กำลังพิมพ์..." else "${members.size} AI · แตะ ⓘ ดูข้อมูลกลุ่ม", color = Color.Gray, fontSize = 12.sp)
            }
            TextButton(onClick = info) { Text("ⓘ", fontSize = 22.sp, color = Color.White) }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.toList()) { m ->
                val ps = personas.find { it.id == m.s }
                GBubble(store, nameOf(m.s), ps?.avatar ?: "", m)
            }
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        OutlinedButton(
            onClick = { round() }, enabled = !busy && members.isNotEmpty(),
            modifier = Modifier.padding(horizontal = 8.dp)
        ) { Text("💬 ให้ AI คุยกันต่อ", fontSize = 12.sp) }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("พิมพ์ข้อความ...") }, maxLines = 4, colors = fc()
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ส่ง") }
        }
    }
}

@Composable
fun MemberRow(store: Store, p: Persona, checked: Boolean, toggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = { toggle() })
        Avatar(store, p.name, p.avatar, 36)
        Spacer(Modifier.width(10.dp))
        Text(p.name, color = Color.White)
    }
}

@Composable
fun GroupCreateScreen(store: Store, back: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf(false) }
    val ps = remember { store.personas() }
    val sel = remember { mutableStateListOf<String>() }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "สร้างกลุ่ม")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name.ifBlank { "?" }, avatar, 64)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เลือกรูปกลุ่ม") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อกลุ่ม") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(desc, { desc = it }, label = { Text("คำอธิบาย") }, minLines = 2, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("เลือกสมาชิก AI", color = Color.Gray, fontSize = 12.sp)
        if (ps.isEmpty()) Text("ยังไม่มีตัวละคร สร้างที่ เพิ่มเติม > Create Character ก่อน", color = Color(0xFFFFC857))
        ps.forEach { p -> MemberRow(store, p, p.id in sel) { if (p.id in sel) sel.remove(p.id) else sel.add(p.id) } }
        Button(
            onClick = {
                store.saveGroups(store.groups() + Group(UUID.randomUUID().toString().take(8), name.trim(), desc.trim(), avatar, sel.toList()))
                back()
            },
            enabled = name.isNotBlank() && sel.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("สร้างกลุ่ม") }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
}

@Composable
fun GroupInfoScreen(store: Store, id: String, back: () -> Unit, onDeleted: () -> Unit) {
    val g = remember { store.groups().find { it.id == id } }
    if (g == null) { Center("ไม่พบกลุ่ม"); return }
    var name by remember { mutableStateOf(g.name) }
    var desc by remember { mutableStateOf(g.desc) }
    var avatar by remember { mutableStateOf(g.avatar) }
    var pick by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val ps = remember { store.personas() }
    val sel = remember { mutableStateListOf<String>().apply { addAll(g.members) } }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "ข้อมูลกลุ่ม")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name, avatar, 72)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เปลี่ยนรูปกลุ่ม") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อกลุ่ม") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(desc, { desc = it }, label = { Text("คำอธิบาย") }, minLines = 2, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("สมาชิก AI (${sel.size})", color = Color.Gray, fontSize = 12.sp)
        ps.forEach { p -> MemberRow(store, p, p.id in sel) { if (p.id in sel) sel.remove(p.id) else sel.add(p.id) } }
        Button(
            onClick = {
                val ok = sel.filter { m -> ps.any { it.id == m } }
                store.saveGroups(store.groups().map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }, desc = desc.trim(), avatar = avatar, members = ok) else it })
                back()
            },
            enabled = sel.isNotEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("บันทึก") }
        OutlinedButton(onClick = { confirm = true }) { Text("ลบกลุ่ม", color = Color(0xFFFF6B6B)) }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("ลบกลุ่ม ${g.name} และประวัติแชตทั้งหมด?") },
        confirmButton = {
            TextButton(onClick = { store.saveGroups(store.groups().filter { it.id != id }); store.deleteG(id); onDeleted() }) { Text("ลบ") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("ยกเลิก") } }
    )
}
