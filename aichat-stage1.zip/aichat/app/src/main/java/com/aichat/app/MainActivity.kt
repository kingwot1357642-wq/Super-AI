package com.aichat.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

val Purple = Color(0xFF7B2FF7)
val Panel = Color(0xFF0D0D0D)

data class Msg(val fromUser: Boolean, val text: String)
data class Cfg(val url: String, val key: String, val model: String)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
    fun cfg() = Cfg(p.getString("url", "") ?: "", p.getString("key", "") ?: "", p.getString("model", "") ?: "")
    fun saveCfg(c: Cfg) = p.edit().putString("url", c.url).putString("key", c.key).putString("model", c.model).apply()
    fun loadChat(): List<Msg> {
        val a = JSONArray(p.getString("chat_assistant", "[]"))
        return List(a.length()) { val o = a.getJSONObject(it); Msg(o.getBoolean("u"), o.getString("t")) }
    }
    fun saveChat(m: List<Msg>) {
        val a = JSONArray()
        m.forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
        p.edit().putString("chat_assistant", a.toString()).apply()
    }
}

const val ASSISTANT_PROMPT = "คุณคือ Assistant ผู้ช่วยประจำแอป พูดสุภาพ เป็นกันเอง ตอบเป็นภาษาเดียวกับผู้ใช้"

suspend fun callModel(cfg: Cfg, history: List<Msg>): String = withContext(Dispatchers.IO) {
    if (cfg.url.isBlank() || cfg.model.isBlank()) error("ยังไม่ได้ตั้งค่า More > Model Connection")
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", ASSISTANT_PROMPT))
    history.takeLast(20).forEach {
        msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
    }
    val body = JSONObject().put("model", cfg.model).put("messages", msgs)
    val conn = (URL(cfg.url.trim().trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        setRequestProperty("Content-Type", "application/json")
        if (cfg.key.isNotBlank()) setRequestProperty("Authorization", "Bearer " + cfg.key.trim())
        doOutput = true
        connectTimeout = 20000
        readTimeout = 120000
    }
    conn.outputStream.use { it.write(body.toString().toByteArray()) }
    val code = conn.responseCode
    val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
    if (code !in 200..299) error("HTTP $code ${text.take(200)}")
    JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(applicationContext) }
    }
}

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var inChat by remember { mutableStateOf(false) }
    var sub by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = inChat || sub != null) { inChat = false; sub = null }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color.Black, surface = Color.Black)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            when {
                inChat -> ChatScreen(store) { inChat = false }
                sub == "model" -> ModelScreen(store) { sub = null }
                sub != null -> Placeholder(sub!!) { sub = null }
                else -> Scaffold(
                    containerColor = Color.Black,
                    bottomBar = {
                        NavigationBar(containerColor = Panel) {
                            listOf("💬" to "แชต", "👥" to "กลุ่ม", "☰" to "เพิ่มเติม").forEachIndexed { i, (ic, t) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(ic, fontSize = 20.sp) }, label = { Text(t) },
                                    colors = NavigationBarItemDefaults.colors(indicatorColor = Purple.copy(alpha = 0.35f))
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            0 -> ChatList(store) { inChat = true }
                            1 -> Center("กลุ่ม — มาในขั้นตอนที่ 4")
                            else -> MoreScreen { sub = it }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Center(t: String) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t, color = Color.Gray) }

@Composable
fun Avatar(letter: String, size: Int = 44) = Box(
    Modifier.size(size.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center
) { Text(letter, color = Color.White, fontSize = (size / 2).sp) }

@Composable
fun ChatList(store: Store, open: () -> Unit) {
    val last = store.loadChat().lastOrNull()?.text ?: "แตะเพื่อเริ่มคุย"
    Column(Modifier.fillMaxSize()) {
        Text("แชต", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        Row(Modifier.fillMaxWidth().clickable { open() }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar("A")
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Assistant", color = Color.White, fontSize = 16.sp)
                Text(last.take(50), color = Color.Gray, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun ChatScreen(store: Store, onBack: () -> Unit) {
    val msgs = remember { mutableStateListOf<Msg>().apply { addAll(store.loadChat()) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""; err = null
        msgs.add(Msg(true, t)); store.saveChat(msgs); busy = true
        scope.launch {
            try {
                val r = callModel(store.cfg(), msgs.toList())
                msgs.add(Msg(false, r)); store.saveChat(msgs)
            } catch (e: Exception) {
                err = "⚠️ " + (e.message ?: "เชื่อมต่อโมเดลไม่ได้")
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp, color = Color.White) }
            Avatar("A", 38)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Assistant", color = Color.White, fontSize = 16.sp)
                Text(if (busy) "กำลังพิมพ์..." else "ออนไลน์", color = Color.Gray, fontSize = 12.sp)
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.toList()) { Bubble(it) }
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("พิมพ์ข้อความ...") }, maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Purple.copy(alpha = 0.5f))
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ส่ง") }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        val mod = if (m.fromUser) Modifier.background(Purple, shape)
        else Modifier.background(Color.Black, shape).border(1.dp, Purple, shape)
        Box(Modifier.widthIn(max = 280.dp).then(mod).padding(12.dp)) { Text(m.text, color = Color.White) }
    }
}

@Composable
fun MoreScreen(open: (String) -> Unit) {
    val items = listOf(
        "model" to "Model Connection — เชื่อมต่อโมเดล",
        "char" to "Create Character — สร้างตัวละคร",
        "gallery" to "Image Gallery — จัดการรูปโปรไฟล์",
        "manage" to "AI Management — จัดการ AI"
    )
    Column(Modifier.fillMaxSize()) {
        Text("เพิ่มเติม", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        items.forEach { (id, label) ->
            Text(label, color = Color.White, modifier = Modifier.fillMaxWidth().clickable { open(id) }.padding(16.dp))
            HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        }
    }
}

@Composable
fun Placeholder(id: String, back: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TextButton(onClick = back) { Text("← กลับ", color = Color.White) }
        Center("เมนูนี้มาในขั้นตอนถัดไป")
    }
}

@Composable
fun ModelScreen(store: Store, back: () -> Unit) {
    val c = remember { store.cfg() }
    var url by remember { mutableStateOf(c.url) }
    var key by remember { mutableStateOf(c.key) }
    var model by remember { mutableStateOf(c.model) }
    var saved by remember { mutableStateOf(false) }
    val colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Purple.copy(alpha = 0.5f))
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = back) { Text("← กลับ", color = Color.White) }
        Text("Model Connection (โมเดลจากที่อื่น)", fontSize = 20.sp, color = Color.White)
        Text("ใช้ได้กับ API แบบ OpenAI เช่น https://api.openai.com/v1, OpenRouter, Ollama (http://IP:11434/v1)", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(url, { url = it; saved = false }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = colors)
        OutlinedTextField(key, { key = it; saved = false }, label = { Text("API Key (เว้นว่างได้)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), colors = colors)
        OutlinedTextField(model, { model = it; saved = false }, label = { Text("ชื่อโมเดล") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = colors)
        Button(onClick = { store.saveCfg(Cfg(url, key, model)); saved = true }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("บันทึก") }
        if (saved) Text("บันทึกแล้ว ✓", color = Color(0xFF9CFF9C))
    }
}
