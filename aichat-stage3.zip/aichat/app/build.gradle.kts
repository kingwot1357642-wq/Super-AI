plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.aichat.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aichat.app"
        minSdk = 26
        targetSdk = 34
        // เพิ่มอัตโนมัติทุกครั้งที่บิลด์บน GitHub เพื่อให้ติดตั้งทับเป็นอัปเดตได้
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.1." + versionCode
    }
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "aichat123"
            keyAlias = "aichat"
            keyPassword = "aichat123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.2")
}
