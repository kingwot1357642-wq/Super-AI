package com.aichat.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

val Purple = Color(0xFF7B2FF7)
val Panel = Color(0xFF0D0D0D)

data class Msg(val fromUser: Boolean, val text: String)
data class Cfg(val url: String, val key: String, val model: String)
data class Persona(val id: String, val name: String, val personality: String, val background: String, val avatar: String)
data class Target(val id: String, val name: String, val avatar: String, val prompt: String)

const val ASSISTANT_PROMPT = "คุณคือ Assistant ผู้ช่วยประจำแอป พูดสุภาพ เป็นกันเอง ตอบเป็นภาษาเดียวกับผู้ใช้"

class Store(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("app", Context.MODE_PRIVATE)
    fun cfg() = Cfg(p.getString("url", "") ?: "", p.getString("key", "") ?: "", p.getString("model", "") ?: "")
    fun saveCfg(c: Cfg) = p.edit().putString("url", c.url).putString("key", c.key).putString("model", c.model).apply()

    private fun key(id: String) = if (id == "assistant") "chat_assistant" else "chat_$id"
    fun loadChat(id: String): List<Msg> {
        val a = JSONArray(p.getString(key(id), "[]"))
        return List(a.length()) { val o = a.getJSONObject(it); Msg(o.getBoolean("u"), o.getString("t")) }
    }
    fun saveChat(id: String, m: List<Msg>) {
        val a = JSONArray()
        m.forEach { a.put(JSONObject().put("u", it.fromUser).put("t", it.text)) }
        p.edit().putString(key(id), a.toString()).apply()
    }
    fun deleteChat(id: String) = p.edit().remove(key(id)).apply()

    fun personas(): List<Persona> {
        val a = JSONArray(p.getString("personas", "[]"))
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Persona(o.getString("id"), o.getString("name"), o.getString("p"), o.getString("b"), o.optString("a", ""))
        }
    }
    fun savePersonas(l: List<Persona>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("p", it.personality).put("b", it.background).put("a", it.avatar)) }
        p.edit().putString("personas", a.toString()).apply()
    }

    private fun dir() = File(ctx.filesDir, "gallery").apply { mkdirs() }
    fun file(name: String) = File(dir(), name)
    fun gallery(): List<String> = dir().listFiles()?.map { it.name }?.sortedDescending() ?: emptyList()
    fun deleteImage(name: String) { file(name).delete() }
    fun addImage(uri: Uri): Boolean {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 800) s *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)!!.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return false
            file("img_${System.currentTimeMillis()}.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return true
        } catch (e: Exception) {
            return false
        }
    }
}

fun targetOf(store: Store, id: String): Target {
    val ps = store.personas().find { it.id == id } ?: return Target("assistant", "Assistant", "", ASSISTANT_PROMPT)
    val prompt = "คุณคือ ${ps.name} ตัวละครในแอปแชต จงเล่นบทบาทนี้อย่างเป็นธรรมชาติ ห้ามหลุดบทบาท ตอบเป็นภาษาเดียวกับผู้ใช้\n" +
        "บุคลิก: ${ps.personality}\nภูมิหลัง: ${ps.background}"
    return Target(ps.id, ps.name, ps.avatar, prompt)
}

suspend fun callModel(cfg: Cfg, system: String, history: List<Msg>): String = withContext(Dispatchers.IO) {
    if (cfg.url.isBlank() || cfg.model.isBlank()) error("ยังไม่ได้ตั้งค่า More > Model Connection")
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
    history.takeLast(20).forEach {
        msgs.put(JSONObject().put("role", if (it.fromUser) "user" else "assistant").put("content", it.text))
    }
    val body = JSONObject().put("model", cfg.model).put("messages", msgs)
    val conn = (URL(cfg.url.trim().trimEnd('/') + "/chat/completions").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        setRequestProperty("Content-Type", "application/json")
        if (cfg.key.isNotBlank()) setRequestProperty("Authorization", "Bearer " + cfg.key.trim())
        doOutput = true
        connectTimeout = 20000
        readTimeout = 120000
    }
    conn.outputStream.use { it.write(body.toString().toByteArray()) }
    val code = conn.responseCode
    val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().readText()
    if (code !in 200..299) error("HTTP $code ${text.take(200)}")
    JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App(applicationContext) }
    }
}

@Composable
fun fc() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Purple.copy(alpha = 0.5f))

@Composable
fun App(ctx: Context) {
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var chatId by remember { mutableStateOf<String?>(null) }
    var sub by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = chatId != null || sub != null) {
        if (chatId != null) chatId = null
        else if (sub?.startsWith("edit:") == true) sub = "manage"
        else sub = null
    }
    val cid = chatId
    val sb = sub
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color.Black, surface = Color.Black)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            when {
                cid != null -> ChatScreen(store, targetOf(store, cid)) { chatId = null }
                sb == "model" -> ModelScreen(store) { sub = null }
                sb == "char" -> CreateScreen(store) { sub = null }
                sb == "gallery" -> GalleryScreen(store) { sub = null }
                sb == "manage" -> ManageScreen(store, { sub = null }) { sub = "edit:$it" }
                sb != null && sb.startsWith("edit:") -> EditScreen(store, sb.removePrefix("edit:")) { sub = "manage" }
                else -> Scaffold(
                    containerColor = Color.Black,
                    bottomBar = {
                        NavigationBar(containerColor = Panel) {
                            listOf("💬" to "แชต", "👥" to "กลุ่ม", "☰" to "เพิ่มเติม").forEachIndexed { i, (ic, t) ->
                                NavigationBarItem(
                                    selected = tab == i, onClick = { tab = i },
                                    icon = { Text(ic, fontSize = 20.sp) }, label = { Text(t) },
                                    colors = NavigationBarItemDefaults.colors(indicatorColor = Purple.copy(alpha = 0.35f))
                                )
                            }
                        }
                    }
                ) { pad ->
                    Box(Modifier.padding(pad).fillMaxSize()) {
                        when (tab) {
                            0 -> ChatList(store) { chatId = it }
                            1 -> Center("กลุ่ม — มาในขั้นตอนที่ 4")
                            else -> MoreScreen { sub = it }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Center(t: String) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t, color = Color.Gray) }

@Composable
fun Avatar(store: Store, name: String, file: String, size: Int = 44) {
    val bmp = remember(file) { if (file.isBlank()) null else BitmapFactory.decodeFile(store.file(file).path)?.asImageBitmap() }
    if (bmp != null) {
        Image(bmp, null, Modifier.size(size.dp).clip(CircleShape), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size.dp).background(Purple, CircleShape), contentAlignment = Alignment.Center) {
            Text(name.take(1).uppercase(), color = Color.White, fontSize = (size / 2).sp)
        }
    }
}

@Composable
fun AvatarPicker(store: Store, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val g = remember { store.gallery() }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("เลือกรูปโปรไฟล์") },
        text = {
            if (g.isEmpty()) Text("ยังไม่มีรูป ไปเพิ่มที่ เพิ่มเติม > Image Gallery ก่อน")
            else LazyVerticalGrid(GridCells.Fixed(3), Modifier.heightIn(max = 300.dp)) {
                items(g) { n -> Box(Modifier.padding(4.dp).clickable { onPick(n) }) { Avatar(store, "", n, 76) } }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("ปิด") } },
        dismissButton = { TextButton(onClick = { onPick("") }) { Text("ไม่ใช้รูป") } }
    )
}

@Composable
fun ChatList(store: Store, open: (String) -> Unit) {
    val items = listOf(Target("assistant", "Assistant", "", "")) + store.personas().map { Target(it.id, it.name, it.avatar, "") }
    Column(Modifier.fillMaxSize()) {
        Text("แชต", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        LazyColumn {
            items(items) { t ->
                val last = store.loadChat(t.id).lastOrNull()?.text ?: "แตะเพื่อเริ่มคุย"
                Row(Modifier.fillMaxWidth().clickable { open(t.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(store, t.name, t.avatar)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(t.name, color = Color.White, fontSize = 16.sp)
                        Text(last.take(50), color = Color.Gray, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(store: Store, target: Target, onBack: () -> Unit) {
    val msgs = remember { mutableStateListOf<Msg>().apply { addAll(store.loadChat(target.id)) } }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || busy) return
        input = ""; err = null
        msgs.add(Msg(true, t)); store.saveChat(target.id, msgs); busy = true
        scope.launch {
            try {
                val r = callModel(store.cfg(), target.prompt, msgs.toList())
                msgs.add(Msg(false, r)); store.saveChat(target.id, msgs)
            } catch (e: Exception) {
                err = "⚠️ " + (e.message ?: "เชื่อมต่อโมเดลไม่ได้")
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←", fontSize = 22.sp, color = Color.White) }
            Avatar(store, target.name, target.avatar, 38)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(target.name, color = Color.White, fontSize = 16.sp)
                Text(if (busy) "กำลังพิมพ์..." else "ออนไลน์", color = Color.Gray, fontSize = 12.sp)
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.toList()) { Bubble(it) }
        }
        err?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp)) }
        Row(Modifier.fillMaxWidth().background(Panel).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("พิมพ์ข้อความ...") }, maxLines = 4, colors = fc()
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("ส่ง") }
        }
    }
}

@Composable
fun Bubble(m: Msg) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        val mod = if (m.fromUser) Modifier.background(Purple, shape)
        else Modifier.background(Color.Black, shape).border(1.dp, Purple, shape)
        Box(Modifier.widthIn(max = 280.dp).then(mod).padding(12.dp)) { Text(m.text, color = Color.White) }
    }
}

@Composable
fun MoreScreen(open: (String) -> Unit) {
    val items = listOf(
        "model" to "Model Connection — เชื่อมต่อโมเดล",
        "char" to "Create Character — สร้างตัวละคร",
        "gallery" to "Image Gallery — จัดการรูปโปรไฟล์",
        "manage" to "AI Management — จัดการ AI"
    )
    Column(Modifier.fillMaxSize()) {
        Text("เพิ่มเติม", fontSize = 24.sp, color = Color.White, modifier = Modifier.padding(16.dp))
        items.forEach { (id, label) ->
            Text(label, color = Color.White, modifier = Modifier.fillMaxWidth().clickable { open(id) }.padding(16.dp))
            HorizontalDivider(color = Purple.copy(alpha = 0.3f))
        }
    }
}

@Composable
fun BackRow(back: () -> Unit, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = back) { Text("←", fontSize = 22.sp, color = Color.White) }
        Text(title, fontSize = 20.sp, color = Color.White)
    }
}

@Composable
fun ModelScreen(store: Store, back: () -> Unit) {
    val c = remember { store.cfg() }
    var url by remember { mutableStateOf(c.url) }
    var key by remember { mutableStateOf(c.key) }
    var model by remember { mutableStateOf(c.model) }
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "Model Connection")
        Text("ใช้ได้กับ API แบบ OpenAI เช่น https://api.openai.com/v1, OpenRouter, Ollama (http://IP:11434/v1)", color = Color.Gray, fontSize = 12.sp)
        OutlinedTextField(url, { url = it; saved = false }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(key, { key = it; saved = false }, label = { Text("API Key (เว้นว่างได้)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(model, { model = it; saved = false }, label = { Text("ชื่อโมเดล") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        Button(onClick = { store.saveCfg(Cfg(url, key, model)); saved = true }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("บันทึก") }
        if (saved) Text("บันทึกแล้ว ✓", color = Color(0xFF9CFF9C))
    }
}

@Composable
fun GalleryScreen(store: Store, back: () -> Unit) {
    var imgs by remember { mutableStateOf(store.gallery()) }
    var del by remember { mutableStateOf<String?>(null) }
    var failed by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { failed = !store.addImage(uri); imgs = store.gallery() }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        BackRow(back, "Image Gallery")
        Button(onClick = { launcher.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("+ เพิ่มรูป") }
        if (failed) Text("เพิ่มรูปไม่สำเร็จ", color = Color(0xFFFF6B6B))
        Text("แตะรูปเพื่อลบ", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
        LazyVerticalGrid(GridCells.Fixed(3)) {
            items(imgs) { n -> Box(Modifier.padding(4.dp).clickable { del = n }) { Avatar(store, "", n, 100) } }
        }
    }
    del?.let { n ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("ลบรูปนี้?") },
            confirmButton = { TextButton(onClick = { store.deleteImage(n); imgs = store.gallery(); del = null }) { Text("ลบ") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("ยกเลิก") } }
        )
    }
}

@Composable
fun CreateScreen(store: Store, back: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var pers by remember { mutableStateOf("") }
    var bg by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "Create Character")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name.ifBlank { "?" }, avatar, 64)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เลือกรูปโปรไฟล์") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อ") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(pers, { pers = it }, label = { Text("บุคลิก") }, minLines = 3, modifier = Modifier.fillMaxWidth(), colors = fc())
        OutlinedTextField(bg, { bg = it }, label = { Text("ภูมิหลัง") }, minLines = 3, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("⚠️ บุคลิกและภูมิหลังแก้ไขไม่ได้หลังสร้าง หากต้องการเปลี่ยนต้องสร้างตัวละครใหม่", color = Color(0xFFFFC857), fontSize = 12.sp)
        Button(
            onClick = {
                val ps = Persona(UUID.randomUUID().toString().take(8), name.trim(), pers.trim(), bg.trim(), avatar)
                store.savePersonas(store.personas() + ps); back()
            },
            enabled = name.isNotBlank() && pers.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("สร้างตัวละคร") }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
}

@Composable
fun ManageScreen(store: Store, back: () -> Unit, edit: (String) -> Unit) {
    val l = remember { store.personas() }
    Column(Modifier.fillMaxSize()) {
        BackRow(back, "AI Management")
        if (l.isEmpty()) Center("ยังไม่มีตัวละคร สร้างได้ที่ Create Character")
        LazyColumn {
            items(l) { ps ->
                Row(Modifier.fillMaxWidth().clickable { edit(ps.id) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(store, ps.name, ps.avatar)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(ps.name, color = Color.White, fontSize = 16.sp)
                        Text("แตะเพื่อจัดการ", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun EditScreen(store: Store, id: String, back: () -> Unit) {
    val orig = remember { store.personas().find { it.id == id } }
    if (orig == null) { Center("ไม่พบตัวละคร"); return }
    var name by remember { mutableStateOf(orig.name) }
    var avatar by remember { mutableStateOf(orig.avatar) }
    var pick by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BackRow(back, "จัดการ ${orig.name}")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(store, name, avatar, 64)
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = { pick = true }) { Text("เปลี่ยนรูปโปรไฟล์") }
        }
        OutlinedTextField(name, { name = it }, label = { Text("ชื่อ") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fc())
        Text("🔒 บุคลิก (แก้ไขไม่ได้)", color = Color.Gray, fontSize = 12.sp)
        Text(orig.personality, color = Color.White)
        Text("🔒 ภูมิหลัง (แก้ไขไม่ได้)", color = Color.Gray, fontSize = 12.sp)
        Text(orig.background.ifBlank { "-" }, color = Color.White)
        Button(
            onClick = {
                store.savePersonas(store.personas().map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }, avatar = avatar) else it })
                back()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Purple)
        ) { Text("บันทึก") }
        OutlinedButton(onClick = { confirm = true }) { Text("ลบตัวละคร", color = Color(0xFFFF6B6B)) }
    }
    if (pick) AvatarPicker(store, { avatar = it; pick = false }) { pick = false }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("ลบ ${orig.name} และประวัติแชตทั้งหมด?") },
        confirmButton = {
            TextButton(onClick = { store.savePersonas(store.personas().filter { it.id != id }); store.deleteChat(id); back() }) { Text("ลบ") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("ยกเลิก") } }
    )
}
